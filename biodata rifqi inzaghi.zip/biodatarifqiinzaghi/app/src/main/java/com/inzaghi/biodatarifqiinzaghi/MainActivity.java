package com.inzaghi.biodatarifqiinzaghi;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button alamat;
    Button email;
    Button telephone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alamat = findViewById(R.id.alamat);
        email = findViewById(R.id.email);
        telephone = findViewById(R.id.telephone);
    }
    public void MapsIntent(View view) {
        Uri mapsUri;
        mapsUri = Uri.parse("https://goo.gl/maps/XjU9opdbWQbfmBSP8");
        Intent mapsIntent = new Intent(Intent.ACTION_VIEW, mapsUri);
        startActivity(mapsIntent);
    }
    public void telephoneIntent(View view) {
        String phoneNumber = "081359489286";
        Intent phoneIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
        startActivity(phoneIntent);
    }
    public void emailIntent(View view){
        Uri emailUri = Uri.parse("111202012951@mhs.dinus.ac.id");
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + emailUri));
        startActivity(emailIntent);
    }
}



